
#include "TaraOS.h"

unsigned CURSOR_X = 0;
unsigned CURSOR_Y = 0;



int kmain()
{
	
	//char* vm = 0xA0000;
	//unsigned char ch;
	//unsigned _ch;
	init_idt();
	
	asm("int $0x0");
	
	while(1);
}

